# i have a blog
#### March 1, 2025
Today, I thought about having a blog—again.
Eleven years ago, I made a Blogspot and never wrote anything in it.

Things only happen when you make them, when you put something into them, name them, or even just consider them to exist—even if they don’t.

Lately, I’ve been thinking a lot about my presence on the web. The web is this huge space where you can take as much as you want, but that rarely happens. Nobody comes to our little corners if we claim them. So, we all end up hanging out in the spaces built for us, even if we hate them or find them uncomfortable.

I want to have my own spaces, even if they’re empty. I visit other people’s spaces a lot. Maybe some people will visit mine too. And if they don’t, at least my space will still be here, and that’s what matters—the alternative.

The internet has become either boring or useless a lot of the time.

That’s why this blog is a step toward creating my own spaces—a place to write whatever I want, even if it’s just words to myself.

I have a blog now.
<!-- ![img](/assets/1.jpg) -->


